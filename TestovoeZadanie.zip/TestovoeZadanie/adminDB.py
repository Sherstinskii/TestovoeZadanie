python manage.py createsuperuser
python manage.py runserver
