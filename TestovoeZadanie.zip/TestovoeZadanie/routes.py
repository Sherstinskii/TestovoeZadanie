from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AvailableProductViewSet, PayProductView

router = DefaultRouter()
router.register(r'available-products', AvailableProductViewSet, basename='available-products')

urlpatterns = [
    path('pay/<int:product_id>/', PayProductView.as_view(), name='pay-product'),
    path('', include(router.urls)),
]


