from rest_framework import status, views
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Product, UserAccess, UserBalance

class PayProductView(views.APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, product_id):
        product = Product.objects.get(id=product_id)
        user_balance = request.user.balance

        if product.user_accesses.filter(user=request.user).exists():
            return Response({"detail": "Product already purchased."}, status=status.HTTP_400_BAD_REQUEST)

        if user_balance.deduct(product.price):
            UserAccess.objects.create(user=request.user, product=product, access_granted=True)
            self.assign_user_to_group(request.user)
            return Response({"detail": "Payment successful, access granted."}, status=status.HTTP_200_OK)
        return Response({"detail": "Insufficient balance."}, status=status.HTTP_400_BAD_REQUEST)

    def assign_user_to_group(self, user):
        groups = StudentGroup.objects.annotate(num_students=models.Count('students')).order_by('num_students')
        group = groups.first()
        group.students.add(user)

