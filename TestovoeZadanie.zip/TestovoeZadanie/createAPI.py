from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Product

class ProductSerializer(serializers.ModelSerializer):
    lessons_count = serializers.IntegerField(source='lessons.count', read_only=True)

    class Meta:
        model = Product
        fields = ['id', 'title', 'creator', 'start_date_time', 'price', 'lessons_count']

class AvailableProductViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return Product.objects.filter(is_available=True).exclude(user_accesses__user=user)
