from django.db import models
from django.contrib.auth.models import User

class Product(models.Model):
    title = models.CharField(max_length=255)
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_products')
    start_date_time = models.DateTimeField()
    price = models.PositiveIntegerField()
    is_available = models.BooleanField(default=True)

    def __str__(self):
        return self.title

class Lesson(models.Model):
    title = models.CharField(max_length=255)
    video_url = models.URLField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='lessons')

    def __str__(self):
        return self.title

class UserAccess(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='accesses')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='user_accesses')
    access_granted = models.BooleanField(default=False)
    date_granted = models.DateTimeField(auto_now_add=True)
    expiration_date = models.DateTimeField(null=True, blank=True)

class UserBalance(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='balance')
    balance = models.PositiveIntegerField(default=1000)

    def deduct(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            self.save()
            return True
        return False

class StudentGroup(models.Model):
    name = models.CharField(max_length=50)
    students = models.ManyToManyField(User, related_name='student_groups')
